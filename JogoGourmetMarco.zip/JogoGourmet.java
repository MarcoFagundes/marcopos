package jogogourmet;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


/*
 * @author Marco Fagundes - Jogo Gourmet - 04/02/2021
 */
interface game{
	void jogar();
	
}
public class JogoGourmet implements game {
    public int acertos = 0;
    
    
    public void jogar(){
    	
 // Definindo os pratos a serem listrados
    	
    	final ArrayList<prato> menu = new ArrayList<>();
    	menu.add(new prato(1,"Lazanha","", "massa"));
    	menu.add(new prato(2,"Bolo de Chocolate","", "")); 
        JFrame frmJogoGourmet = new JFrame("Jogo Gourmet");
        JLabel lblJogoGourmet = new JLabel("Pense em um prato que gosta", JLabel.CENTER);
        JPanel lblPanel = new JPanel();
        
        // Configurando o painel
        BoxLayout boxlayout = new BoxLayout(lblPanel, BoxLayout.Y_AXIS);
        lblPanel.setLayout(boxlayout);
       lblPanel.setBorder(new EmptyBorder(new Insets(12, 105, 12, 110)));
       
        // Definindo botões
        JButton jb1 = new JButton("OK");
        jb1.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
        	String tippEscolhido="";
        int respostaMassa = JOptionPane.YES_NO_OPTION;
        respostaMassa = JOptionPane.showConfirmDialog(frmJogoGourmet, "O prato que você pensou é massa?", "Confirm", respostaMassa);
        if (respostaMassa==JOptionPane.YES_NO_OPTION) {
        	tippEscolhido="massa";
                acertos++;
        }
        
        String ultimoPratoNome="";	
        for (prato itemMenu : menu)
	            {	if (itemMenu.pratoTipo==tippEscolhido){
	        			int respostaPratoConfirmado = JOptionPane.YES_NO_OPTION;
	        			ultimoPratoNome=itemMenu.pratoNome;
	        			
	        				
	        			if (itemMenu.pratoComplemento!="") {
                                            respostaPratoConfirmado = JOptionPane.showConfirmDialog(frmJogoGourmet, "O prato que você pensou é " + itemMenu.pratoComplemento+" ?", "Confirm", respostaPratoConfirmado);
                                            if( respostaPratoConfirmado == JOptionPane.NO_OPTION) {
                                                      acertos=0;

                                            }
                                            else {
                                                        respostaPratoConfirmado = JOptionPane.showConfirmDialog(frmJogoGourmet, "O prato que você pensou é " + itemMenu.pratoNome+" ?", "Confirm", respostaPratoConfirmado);
                                                        if( respostaPratoConfirmado == JOptionPane.YES_OPTION) {
                                                                acertos++;
                                                                
                                                                 }
                                                        else{
                                                                acertos=0;
                                                             }
                                                         break;
                                                   }
                                                        
                                               
                                            }
	        			
	        			else {
	        				respostaPratoConfirmado = JOptionPane.showConfirmDialog(frmJogoGourmet, "O prato que você pensou é " + itemMenu.pratoNome+" ?", "Confirm", respostaPratoConfirmado);
			                
	        				if( respostaPratoConfirmado == JOptionPane.YES_OPTION) {
				                  acertos++;
                                                  if (tippEscolhido=="massa"){
                                                    break;
                                                  }
			                	} 
	        				else  {
                                                  
                                                  
	        					 acertos=0;
			                	}  
	        			}


	            }
        }

        
        if (acertos==1)
                {
                JOptionPane.showMessageDialog(frmJogoGourmet,"Acertei!");
                
                }
        else if (acertos>1){
                JOptionPane.showMessageDialog(frmJogoGourmet,"Acertei de novo!");
                
        }
        else{
            String seuprato = JOptionPane.showInputDialog(frmJogoGourmet, "Qual prato você pensou?","Desisto", JOptionPane.QUESTION_MESSAGE);
            if(seuprato==null){
                seuprato="null";
            }
            String seupratoComplemento= JOptionPane.showInputDialog(frmJogoGourmet, seuprato+" é ________  mas " + ultimoPratoNome +" não.","Complete", JOptionPane.QUESTION_MESSAGE);
            if(seupratoComplemento==null){
                seupratoComplemento="null";
            }
            menu.add(new prato(menu.size()+1,seuprato,seupratoComplemento, tippEscolhido)); 
             //Colocando sempre Lazanha e Bolo de Chocolate
            for (prato itemMenu : menu)
             {   if (itemMenu.pratoNome.equals("Lazanha") | itemMenu.pratoNome.equals("Bolo de Chocolate"))
                {
                    itemMenu.pratoId=menu.size()+1;
                }
             };
            
            menu.sort(Comparator.comparing(prato::getPratoId)); 
    

        }  
        
        }
});
        // Add buttons to the frmJogoGourmet (and spaces between buttons)
        lblPanel.add(jb1,BorderLayout.CENTER); 

        frmJogoGourmet.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
         }        
      }); 
       
        frmJogoGourmet.setLayout(new GridLayout(2, 1));
        frmJogoGourmet.add(lblJogoGourmet);
        frmJogoGourmet.add(lblPanel);
        frmJogoGourmet.setLocationRelativeTo(null);
        
        frmJogoGourmet.pack();
        frmJogoGourmet.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmJogoGourmet.setVisible(true);
    }

    public static void main(String[] args) {
        //chamando a criação do jogo
      JogoGourmet Jogador  = new JogoGourmet();
      //começando jogar
      Jogador.jogar();
         

    }
    class prato  
    {  
	    int pratoId;  
	    String pratoNome;
	    String pratoComplemento;
	    String pratoTipo;
	    //Construtor da classe prato
	    prato(int pratoId, String pratoNome,String pratoComplemento,String pratoTipo)  
	    {  
	    	this.pratoId = pratoId;  
	    	this.pratoNome = pratoNome;
	    	this.pratoComplemento = pratoComplemento;
	    	this.pratoTipo = pratoTipo;

	    }
            public int getPratoId() {
                return pratoId;
                }

    }
    
}